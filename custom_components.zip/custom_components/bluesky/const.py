DOMAIN = "bluesky"

PDSHOST = "https://bsky.social"