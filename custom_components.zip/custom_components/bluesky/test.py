import aiohttp
import asyncio
from datetime import datetime, timezone

# Replace these with your actual values
PDSHOST = "https://bsky.social"  # Replace with your actual PDS host
BLUESKY_HANDLE = "screamingtoaster.bsky.social"
BLUESKY_PASSWORD = "5l6f-75j4-kefd-qona"

async def create_session():
    url = f"{PDSHOST}/xrpc/com.atproto.server.createSession"
    headers = {
        "Content-Type": "application/json"
    }
    payload = {
        "identifier": BLUESKY_HANDLE,
        "password": BLUESKY_PASSWORD
    }

    async with aiohttp.ClientSession() as session:
        async with session.post(url, headers=headers, json=payload) as response:
            if response.status == 200:
                data = await response.json()
                # Extract token and refresh_token
                token = data.get("accessJwt")
                refresh_token = data.get("refreshJwt")
                return token, refresh_token
            else:
                error_text = await response.text()
                raise Exception(f"Failed to create session. Status: {response.status}, Error: {error_text}")




async def create_record(message):
    ACCESS_JWT, _ = await create_session()
    print(ACCESS_JWT)
    url = f"{PDSHOST}/xrpc/com.atproto.repo.createRecord"
    headers = {
        "Authorization": f"Bearer {ACCESS_JWT}",
        "Content-Type": "application/json"
    }
    with open('blueskylogo.jpg', 'rb') as f:
      img_data = f.read()
    payload = {
        "repo": BLUESKY_HANDLE,
        "collection": "app.bsky.feed.post",
        "record": {
            "text": message,
            "image": img_data,
            "img_alt": "testing image upload",
            "createdAt": datetime.now(timezone.utc).isoformat()  # Generate current UTC time in ISO 8601 format
        }
    }

    async with aiohttp.ClientSession() as session:
        async with session.post(url, headers=headers, json=payload) as response:
            if response.status == 200:
                data = await response.json()
                print("Record created successfully:", data)
            else:
                error_text = await response.text()
                raise Exception(f"Failed to create record. Status: {response.status}, Error: {error_text}")




async def main():
    try:
        ACCESS_JWT, _ = await create_session()

        await create_record("testing image upload")
    except Exception as e:
        print(e)

# Run the example
asyncio.run(main())